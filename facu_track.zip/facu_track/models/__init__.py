from . import course
from . import student
from . import professor
from . import department
from . import my_location
